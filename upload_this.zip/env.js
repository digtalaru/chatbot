const appVersion = "5.0";
const addON = [""];

module.exports = { appVersion, addON };
